# VECTOR — 기동 · 석궁 · 전장 · 조준 업데이트

로그인 없이 플레이하는 10개 맵 / 36종 무기의 3D FPS입니다. 선택형 계정, AI 봇 연습장, Node.js + Socket.IO 온라인 데스매치를 지원합니다.

## 1. HTML 파일로 바로 플레이

`dist/vector-offline.html`을 더블클릭해 여세요. 모든 3D 엔진·게임 코드·스타일이 한 HTML 파일에 포함되어 있습니다. 서버, npm, 인터넷 없이 건설 현장/전장/협곡 대교/개방 사격장에서 플레이할 수 있습니다. 폴더째 보관했다면 `dist/index.html`도 직접 열 수 있습니다.

- AI 봇 연습장: 움직이며 공격하는 봇 3/6/8/12기, 쉬움/보통/어려움, 무적 켜기/끄기, 처치 후 자동 재생성.
- 고정 표적 사격장: 조준·반동·36종 무기 시험.
- 10개 전장과 고지대 전투 루트, 스프링 야드의 트램펄린 점프 패드.
- 근접 무기 20종마다 우클릭 또는 E로 쓰는 활성 특수 능력과 모바일 특수 버튼.
- 로비 오른쪽 훈련 로봇을 더블 클릭하면 안내 없이 비밀 훈련장으로 입장.
- 플레이어 스킨 10종: 얼굴과 옷·머리 장비가 다른 3D 캐릭터를 무료 선택. 선택은 이 브라우저에 저장되며 온라인 상대에게도 같은 스킨이 표시됩니다.
- 매칭 AI 봇은 서버에서 무작위 스킨을 배정하며, 같은 방에서는 가능한 서로 다른 스킨을 착용합니다.
- 웨이브 서바이벌 및 3분 타임 어택.
- 기록과 설정은 브라우저에 저장됩니다.

HTML 파일에서도 실행 중인 Node.js 서버의 HTTPS 주소를 입력하면 로그인과 온라인 대전에 접속할 수 있습니다. 온라인 기능은 서버에 연결되어야 합니다.

## 전투 감각과 피해량

- 일반 이동·달리기·슬라이드·착지에 서로 다른 소리를 적용하고, 직접 생성한 반복 배경음악을 넣었습니다. 설정에서 효과음과 배경음악 음량을 각각 조절합니다.
- OS-1 OBLIVION은 몸통 240 피해, 단발 탄창, 예비 5발, 재장전 3.8초의 한방 저격총입니다. 가격은 2,800 C입니다.

- 플레이어는 **200 HP**, AI 봇과 고정 표적은 **100 HP**입니다. 웨이브 완료 시 플레이어 체력을 200으로 전부 회복합니다. 온라인 참가·경기 시작·부활도 200으로 시작합니다.

- 명중 시 피해 숫자와 헤드/몸통 구분을 표시하고, 맞은 캐릭터는 잠깐 빨갛게 변합니다. 처치된 AI도 짧게 빨간 잔상을 남깁니다. 플레이어 피격 시 화면 가장자리에 빨간 반응을 표시합니다(무적 연습 중에도 피격 반응은 표시).
- 플레이 중 시스템 마우스 커서는 숨기고 화면 중앙의 십자 조준점으로 조준합니다. 마우스 이동으로 십자 조준점 방향과 시점이 함께 돌아가며, 메뉴·무기고·전투 결과에서는 커서가 다시 표시됩니다. 마우스만 움직여 시점을 돌립니다. 전투 시작 클릭 시 맵을 만들기 전에 마우스를 고정하고 상대 이동량으로 제한 없이 회전합니다. 지원 환경에서는 마우스 가속을 해제한 입력을 쓰며, 지원하지 않으면 일반 잠금으로 재시도합니다. 잠금이 막힌 환경에서는 고정 재시도 버튼과 Chrome 실행 링크를 표시하며, 화면 가장자리의 보조 회전은 부드럽게 가속·감속합니다. ESC 키로만 전투 메뉴를 엽니다. 창 전환·포인터 잠금 해제·화면 이탈로 자동 일시정지하지 않습니다. V로 1·3인칭을 전환하고, F는 근접 공격 후 이전 무기로 돌아갑니다. 조준 중에는 총 모델을 내려 중앙 시야를 확보합니다.
- 봇 사격에는 총구 불꽃, 총의 뒤로 밀림, 팔 반동과 복귀 동작을 표시합니다. 온라인 상대의 사격에도 같은 반동을 적용합니다.
- 무기마다 탄창과 예비 탄약이 다릅니다. HUD의 `탄창 안 탄약 / 예비 탄약`과 남은 총 탄약, 무기고의 초기 총 탄약을 구분합니다. 예: VX-01은 30 + 150발, AWP는 5 + 25발, 활은 1 + 24발, RPG는 1 + 6발입니다. 재장전은 예비 탄약에서 필요한 만큼만 옮기며, 다 쓰면 더 이상 발사/재장전할 수 없습니다. 온라인 서버도 같은 규칙을 적용하고 부활 시 보충합니다. AI 봇/고정 표적 연습에서는 **T** 또는 화면의 **훈련 탄약 보충** 버튼으로 직접 보충할 수 있습니다.
- 근접 무기 20종: 전술 단검·커브 나이프·스틸레토·카람빗·카타나·세이버·대검·레이피어·손도끼·전투 도끼·할버드·전술 망치·대형 해머·야구 배트·경찰봉·전투 창·삼지창·봉·낫·쇠지렛대. 외형, 피해량, 헤드 배율, 사거리(1.9~4.1m), 공격 간격, 이동 속도가 다릅니다. 탄약은 쓰지 않으며 엄폐물을 관통하지 않습니다.
- 근접 공격은 정면 베기와 후면 찌르기로 구분합니다. 상대가 보는 방향의 뒤쪽 중앙 120°에서 후면 판정을 받으며, 일반 근접 무기의 후면 피해는 정면의 1.5~1.8배입니다. 스틸레토·카람빗·레이피어는 후면 명중 시 200 피해로 한방 처치합니다. 엄폐·사거리·아군·부활 보호 판정은 동일하게 적용합니다.
- 전술 단검·카타나·봉은 장착 중 공중 점프를 한 번 추가해 총 3단 점프를 사용할 수 있습니다. 커브 나이프·세이버·전투 도끼·낫은 적중 시 체력을 회복하고, 대검·할버드·망치·경찰봉·삼지창은 짧은 기절을 부여합니다. 손도끼·야구 배트·전투 창·쇠지렛대는 적중 시 사용한 총기의 탄창을 채우고 예비탄 일부를 보충합니다. 효과·수치·재사용 시간은 무기고에 표시합니다.
- 회복·기절·보급은 적중할 때만 발동하고 재사용 시간은 무기를 바꿔도 공유합니다. 온라인에서는 서버가 방향·피해·기절·회복·보급을 판정합니다. 웨이브 완료 시 체력 200과 주무기·보조무기의 탄창·예비탄을 모두 채우고 진행 중인 재장전을 취소합니다.


- 무기마다 몸통 피해, 헤드 배율, 연사력, 탄창, 반동, 조준 속도와 사거리가 다릅니다. 무기고와 게임 HUD에 실제 수치를 표시합니다. 예: VX-01 몸통 26 / 헤드 46.8, AK-12 몸통 34 / 헤드 56.1, AWP 몸통 95 / 헤드 190 (근거리 기준).
- 산탄총은 **산탄 1개당 피해 × 산탄 수**로 표시합니다. 각 산탄이 별도로 명중·거리를 계산하므로 전탄 명중과 일부 명중의 피해가 다릅니다. 무기마다 지정된 거리 이후 피해가 선형 감소하고 최소 피해율에서 멈춥니다.
- 얼굴·바이저·헬멧을 아우르는 머리 영역과 몸통/팔/다리를 별도로 계산합니다. 총에 맞은 것은 몸통 명중으로 계산하지 않습니다. 연습장과 온라인 서버는 동일한 탄도·명중 영역·피해 계산 코드를 사용합니다. 온라인 피해는 서버가 확정합니다.
- **피해량 테스트 사격장**은 100 HP 표적, 표적 체력 바, 떠오르는 피해 숫자, 마지막 명중 부위·피해량·거리·남은 체력을 표시합니다. 처치한 표적은 다시 생성됩니다. 온라인에서는 피해 판정을 서버 응답 후 표시합니다.
- 이동은 짧은 물리 단계로 처리하며 가속·감속, 공중 방향 전환과 관성, 슬라이드 조향, 이단 점프를 지원합니다. 발판 끝 0.1초 점프 유예와 착지 직전 0.14초 입력 버퍼를 적용했습니다. 조준 전환, 발걸음, 착지, 마우스 방향에 따른 무기 흔들림, 반동 복귀를 부드럽게 연결합니다. 설정에서 화면 흔들림을 끌 수 있습니다. 온라인 상대의 부활 위치는 즉시 반영하고, 평상시 이동·앉기·회전은 부드럽게 이어집니다.

### 영상 참고 무기와 빠른 전환

총기 51종, 활·RPG 각 1종, 근접 무기 20종을 제공합니다. 기본 무기 VX-01 / USP-9 / KN-1과 500 C를 지급하고, 나머지는 무기고에서 코인으로 구매합니다. 웨이브 완료 시 100 + 웨이브×25 C, 팀전 승리 시 300 + 팀 인원×50 C를 받습니다. 온라인 구매·승리 보상은 서버에 저장하며 중복 보상은 지급하지 않습니다. 서버 없는 HTML 플레이의 코인과 구매는 브라우저에 저장됩니다. 1 주무기 / 2 보조 / 3 근접 무기를 빠르게 전환하고 Q·휠로 장착 슬롯을 순환합니다. 무기고에서 고른 활과 일반 총기는 1번, 권총은 2번, 근접 무기는 3번, RPG는 주무기 슬롯에 저장됩니다. 무기를 바꿔도 탄창과 예비 탄약이 보존되며, 빈 탄창은 남은 예비 탄약으로 재장전해야 합니다. 온라인에서는 무기 전환·재장전 확인 응답과 서버 상태로 탄창을 맞춥니다. 메뉴를 열어 둔 사이 재장전이 끝나면 복귀 즉시 반영하고, 사망 직전 거절된 전환도 서버 무기로 복원합니다.

- CB-1 WINDRUNNER: 왼쪽 버튼을 0.85초까지 당겼다가 놓아 발사합니다. 완충 몸통 80 / 헤드 144, 약한 당김은 50%부터 증가합니다. 화살은 실제로 비행하고 떨어지므로 먼 적을 미리 조준해야 합니다. Esc나 무기 전환은 당김을 취소합니다.
- RL-1 COMET: 로켓이 비행 후 폭발합니다. 직격 105, 주변 최대 80, 반경 5m이며 엄폐물 너머에는 피해를 주지 않습니다. 자신의 가까운 폭발은 45% 피해와 밀어내기를 적용합니다. 발밑에 발사하면 로켓 점프가 가능합니다. 폭발은 헤드 추가 피해가 없습니다.
- KN-1 SWIFT: 사거리 2.5m, 몸통 45 / 헤드 67.5, 초당 2회 베기. 탄약을 쓰지 않고 총기보다 이동이 빠릅니다.

이 수치는 VECTOR 자체 밸런스이며 라이벌의 정확한 수치를 재현한 것은 아닙니다. 비교 기준과 검증 범위는 `RIVALS-COMPARISON.md`에 기록합니다.

## 2. Node.js로 온라인 서버 실행

Node.js 22 이상에서 실행하세요.

```sh
npm ci --omit=dev
npm start
```

macOS에서는 `Start VECTOR.command`를 실행해도 됩니다. 브라우저에서 http://localhost:4317 을 여세요. 게스트로 바로 플레이할 수 있습니다.

같은 네트워크의 다른 기기는 `http://서버컴퓨터의LAN주소:4317`로 접속하세요. 서버는 기본적으로 `0.0.0.0`에서 수신합니다. `PORT`와 `HOST` 환경 변수로 변경할 수 있습니다.

### 공개 매칭

로비의 **빠른 매칭**에서 **1대1 / 2대2 / 3대3 / 4대4**를 고르고 매칭 시작을 누르세요. 같은 서버의 공개 대기열에 있는 다른 사람과 연결됩니다. 로그인은 선택입니다.

- 같은 인원 모드끼리만 매칭하며, 필요한 실제 플레이어가 모두 모여야 경기를 만듭니다. 대기 중 취소할 수 있습니다. AI 봇으로 빈자리를 채우지 않습니다.
- 먼저 비슷한 레벨과 실력 점수(MMR)를 찾고, 대기가 길어지면 검색 범위를 넓힙니다. 시작 범위는 레벨 ±2 / MMR ±200이며, 최대 레벨 ±12 / MMR ±800입니다.
- 경기 인원을 고른 뒤 가능한 팀 조합을 모두 비교해 **양 팀 평균 레벨 차이**가 가장 작도록 배정합니다. 차이가 같으면 평균 MMR 차이가 작은 조합을 선택합니다.
- 맵은 서버가 4개 중에서 고릅니다. BLUE / ORANGE 팀과 양쪽 평균 레벨이 HUD에 표시됩니다.

### 방 코드 팀전

1. 로비에서 맵을 고르고 **코드 팀전**을 누릅니다.
2. **방 코드** 탭에서 1대1 / 2대2 / 3대3 / 4대4를 선택합니다.
3. 방 코드를 비운 채 방 만들기를 누르고, 코드와 서버 주소를 친구에게 공유합니다.
4. 참가자는 코드를 입력하면 방장이 고른 인원 설정으로 들어갑니다. 예를 들어 3대3은 정확히 6명이 모이면 시작합니다.

코드 방도 평균 레벨과 MMR을 고려해 팀을 자동 배정합니다. 대기 중 인원이 빠지면 계속 대기하며, 시작한 경기는 중간 충원을 허용하지 않습니다.

### 경기 규칙과 레벨

인원이 모이면 3초 카운트다운 뒤 3분 팀 데스매치를 시작합니다. 팀 처치 목표(1대1 10점 / 2대2 20점 / 3대3 30점 / 4대4 40점)를 먼저 달성하면 조기 승리합니다. 시간이 끝나면 점수가 높은 팀이 승리하며, 동점은 무승부입니다. 아군 피해는 없고, 처치 후 3초 뒤 부활하며 2초 동안 보호됩니다. TAB 키로 팀별 처치/사망 순위표를 확인합니다.

- 레벨은 서버가 확인한 온라인 경기의 **승리·처치·어시스트·피해 기여·헤드샷**에 따라 얻은 XP로 오릅니다. 좋은 성과를 낼수록 더 빠르게 성장합니다. 예: 승리 기본 100 XP, 처치 20 XP, 어시스트 10 XP. 레벨 2/3/4/5의 누적 기준은 100/300/600/1000 XP입니다.
- MMR은 상대 팀의 평균 실력과 승패를 반영합니다. 레벨은 누적 성장이고, MMR은 승패에 따라 오르내립니다. 매칭과 팀 균형에 둘 다 사용합니다.
- 오프라인·AI 연습·대기 취소·불완전한 방에서는 레벨이 오르지 않습니다. 클라이언트가 전송한 전투 기록이나 레벨 값으로 XP를 바꿀 수 없습니다.
- 경기 중 나가면 기권패이며 XP는 지급하지 않고 MMR에 불이익을 적용합니다. 팀 전체의 연결이 끊기면 상대 팀이 승리합니다. 15초 미만의 조기 기권 경기에는 승리 XP를 주지 않습니다.
- 결과 창에서 승패, 획득 XP, 이전/현재 레벨, MMR 변화를 확인하고 같은 모드로 다시 매칭할 수 있습니다.

인터넷의 다른 네트워크에서 참가하려면 이 Node.js 서버를 공개 HTTPS 호스트에 배포하거나 터널을 연결하세요. 공개 정적 Sites 링크의 **Node.js 서버 연결 주소**에 서버 주소를 입력해도 됩니다. 로비의 "온라인 서버 연결됨" 표시는 실제 `/api/health` 응답을 확인한 결과입니다.

## 3. 선택형 로그인

게스트에게도 모든 맵·무기·공개 매칭이 열려 있습니다. **로그인 → 회원가입**에서 아이디와 비밀번호로 계정을 만들 수 있습니다. 이메일과 ChatGPT 계정은 필요하지 않습니다. 로그인한 계정의 레벨·MMR·전투 기록은 서버에 저장합니다. 게스트도 서버가 발급한 익명 키로 온라인 레벨을 보관하고, 그 키는 이 브라우저에서 유지합니다. 게스트와 계정의 성장은 별개이며, 다른 기기에서 같은 기록을 이어가려면 같은 계정으로 로그인하세요. 게스트의 오프라인 연습 기록은 브라우저에 저장합니다.

비밀번호는 salt와 scrypt로 해시하고, 세션 토큰도 서버에 해시로 저장합니다. 로그인 토큰은 URL이나 로그에 넣지 않으며 브라우저 세션 저장소에 보관합니다. 익명 게스트 키는 레벨을 이어가기 위해 브라우저 로컬 저장소에 보관합니다. 인증 시도 제한과 WebSocket 메시지 제한이 적용됩니다.

계정, 익명 게스트의 온라인 성장 정보, 경기 기록은 `.data/accounts.json`에 저장됩니다. 서버 재시작 후에도 유지됩니다. 다른 호스트에서는 `DATA_DIR`를 영구 디스크 경로로 설정하세요. Render 무료 인스턴스 등 임시 파일 시스템에서는 재배포 후 데이터가 유지되지 않을 수 있습니다. `.data` 파일은 Git, HTML 파일, 다운로드 ZIP에 포함되지 않습니다.

## 4. 배포

`Dockerfile`과 `render.yaml`을 제공합니다. Node.js 호스트에서 설치 명령은 `npm ci --omit=dev`, 시작 명령은 `node server.mjs`, 상태 확인 경로는 `/api/health`입니다. HTTPS와 Socket.IO(WebSocket/HTTP polling)를 지원하는 호스트를 사용하세요. Docker 예:

```sh
docker build -t vector-strike .
docker run -p 4317:4317 -v vector-data:/app/.data vector-strike
```

공개 정적 사이트는 로그인 없이 HTML/AI 연습을 제공합니다. Node.js 서버 주소가 연결되면 계정과 온라인 기능도 사용할 수 있습니다. 정적 Sites 호스팅에서는 Node.js 프로세스를 직접 실행하지 않습니다.

개발 중 임시 공개 주소가 필요한 경우, [Cloudflare Quick Tunnel](https://developers.cloudflare.com/tunnel/get-started/quick-tunnels/)에서 설명하는 `cloudflared tunnel --url http://localhost:4317` 명령을 사용할 수 있습니다. 이 주소는 터널과 컴퓨터가 켜져 있는 동안에만 유효합니다. 상시 서비스는 고정 호스팅을 사용하세요. `cloudflared`가 설치되어 있으면 `npm run online`으로 Node.js 서버와 임시 터널을 함께 시작하고, `npm run online:stop`으로 종료할 수 있습니다.

## 5. 개발과 검증

```sh
npm ci
npm run check
npm test
npm run build
```

클라이언트는 단일 HTML 안에 모두 번들됩니다. 온라인 서버만 Node.js로 별도 실행합니다. 빌드는 `dist/app.bundle.js`, 단일 파일 `dist/vector-offline.html`, 서버 소스 다운로드 `dist/vector-node.zip`을 생성합니다. 설치용 ZIP은 계정·토큰·런타임 로그를 제외한 실행 소스만 포함합니다.

## 조작

WASD 이동 / Shift 달리기 / Space 점프·이단 점프 / C·Ctrl 슬라이드·앉기 / 마우스 조준 / 왼쪽 클릭 발사 / 오른쪽 클릭 정밀 조준 / R 재장전 / Q·휠 다음 무기 / B 무기고 / Esc 메뉴 / 온라인 TAB 순위표.

임베디드 브라우저에서 포인터 잠금이 막히면 전투 화면의 마우스 고정 버튼을 클릭하세요. 이 환경에서 고정을 지원하지 않으면 표시된 링크를 Chrome에서 열어 플레이하세요. 보조 회전은 화면 가장자리에 커서를 두면 이어지고, 다른 창으로 전환하면 멈춥니다. 터치 기기에는 이동 조이스틱과 발사·점프·슬라이드·재장전 버튼이 표시됩니다.

Three.js r170 (MIT)을 번들에 포함합니다. UI 폰트는 Barlow, Barlow Condensed, Noto Sans KR이며 오프라인에서는 시스템 폰트를 사용합니다.


## 현재 Render 배포

게임과 온라인 서버: https://vector-strike-sid.onrender.com
GitHub 통합 저장소의 `vector-strike/` 폴더를 사용합니다. 자동 배포 상태와 설정은 `DEPLOYMENT.md`에 기록했습니다. Render 무료 웹 서비스는 유휴 시 잠들며 파일 저장소가 재시작·재배포 때 초기화될 수 있으므로 계정/코인의 영구 보존을 보장하지 않습니다. 로컬 `.data`와 `.runtime`는 Git/배포 파일에 포함하지 않습니다.

## 기동·조준·전장 업데이트

- 보조무기 장착 중 E와 방향키로 대시합니다. 방향키 없이 E는 전방으로 이동합니다. WHISPER·STINGER·CLASSIC은 대시형, REGENT·RANGER·PEACEMAKER는 추가 공중 점프형, NEEDLE·ACE는 두 능력을 모두 가집니다. 점프형은 기존 2단 점프에서 총 3단 점프로 늘어납니다. 대시 재사용 시간은 무기를 바꾸어도 공유하며 서버가 판정합니다.
- ARBALEST 단발 석궁과 REPEATER 연발 석궁을 추가했습니다. 클릭 즉시 장전된 볼트를 발사하고 유한 탄창·예비 탄약을 사용합니다. 총기 종류별 총열·조준기·탄창·방아쇠울·세부 부품을 구분했습니다.
- 조준할 때 총을 숨기지 않고 가늠자와 가늠쇠를 중앙으로 정렬합니다. 3인칭 조준은 눈 위치로 부드럽게 전환합니다. 전투 설정에서 기본 조준 1~4배, 저격 조준 1~8배를 고릅니다.
- 맵은 HIGHRISE 건설 현장(내부 충돌물 56개), NO MAN’S LAND 전장(27개), SKYBRIDGE 협곡 다리(10개), OPEN RANGE 개방 사격장(내부 장애물 0개)으로 구성합니다. 렌더링과 온라인 서버는 동일한 배치를 사용합니다.
- 봇은 난이도에 따라 0.32~0.5초 준비한 뒤 고정 방향으로 탄환을 쏩니다. 탄속은 22~30m/s이며 현재 플레이어 위치·앉기·슬라이드 자세와 실제 충돌할 때만 피해를 줍니다. 벽에 막히고 유도되지 않으며 한 발의 최대 피해는 10입니다.
- 재장전은 탄창 제거·삽입·노리쇠 단계로 이어지고, 앉기·슬라이드·피격·공격은 별도의 부드러운 자세를 사용합니다. 무기별 효과음과 이동 소리, 맵·전투 상태에 반응하는 낮은 배경음을 자체 합성합니다.

## 관리자 환경 설정

관리자 계정은 서버 환경 변수 VECTOR_ADMIN_USER와 VECTOR_ADMIN_CREDENTIAL로만 설정합니다. 후자는 16바이트 솔트의 32자리 hex 문자열, 콜론, 해당 솔트 문자열로 계산한 scrypt 64바이트 결과의 128자리 hex 문자열 형식입니다. 비밀번호·솔트·해시는 공개 클라이언트에 포함하지 않습니다. 지정 계정은 서버 시작 시 등록되며 기존 진행 기록을 유지합니다. 일반 회원가입으로 관리자 역할을 지정할 수 없습니다. 관리자 전용 GET /api/admin/status는 인증된 관리자에게만 운영 현황을 반환합니다.

## 모션 제작과 조작 설정

Blender 4.5 LTS에서 제작한 장전·앉기·슬라이드·사격·피격 키프레임은 `assets/animation/vector-motion.blend`에 보관합니다. `scripts/author-motion.py`를 Blender의 백그라운드 Python 실행으로 열면 편집용 리그와 `dist/motion-clips.js`를 다시 생성합니다. 게임은 샘플링된 곡선을 보간하고 팔의 두 관절 IK로 손을 총과 탄창에 연결합니다. 전신 크기를 눌러 앉히지 않고 골반·등·무릎·발목 관절로 자세를 만듭니다. Blender는 제작 때만 필요하며 HTML 실행에 필요하지 않습니다.

설정 → **단축키 · 모바일 버튼 편집**에서 PC 키와 모바일 버튼을 변경합니다. 키가 겹치면 두 동작의 키를 교환하며 ESC는 일시정지·취소로 고정됩니다. 모바일 버튼과 조이스틱은 끌어서 이동하고 선택 후 크기를 조절합니다. 가로·세로 배치를 따로 저장하며 각각 초기화할 수 있습니다. 설정은 이 브라우저에 자동 저장됩니다. 터치 기기에서는 오른쪽 위 메뉴 버튼으로 일시정지 후 설정을 열 수 있습니다.


Mobile controls support an editable shared jump/slide button: tap to jump, or hold while moving to slide. The aim button gently assists toward visible opponents; when it is released, a weapon fires after an opponent stays exactly under the crosshair briefly. Both assist options can be changed in Settings. Double-tap or double-click the lobby robot to enter the hidden Vector Atrium, where fixed bots and bullseye targets respawn after three seconds and duel pads join public 1v1, 2v2, or 3v3 matchmaking. Walk through the EXIT arch to return to the lobby.

The ten arenas include High Citadel, Skyline rooftops, Red Mesa, Iron Foundry, Green Canopy, and Spring Yard. Several maps have climbable high-ground routes; Spring Yard trampoline pads launch players upward. A generated armor tile is applied to player and rival robot meshes, and is embedded in the standalone HTML build.

### 걸어서 들어가는 훈련장
로봇의 비밀 공간에 입장한 뒤 초록색 **봇 훈련장** 문 또는 빨간색 **표적 사격장** 문 안으로 걸어 들어가세요. 봇 훈련장은 색깔별 고정 봇 15기와 거리별 단상, 표적 사격장은 높이·거리가 다른 공중 원형 표적 9개를 갖춥니다. 봇·표적은 체력 100이며 처치 후 3초 뒤 원래 위치에 복원됩니다. 각 훈련장 뒤쪽 **로비로 돌아가기** 문을 걸어 통과하면 3D 로비로 돌아갑니다. 이동 시 체력과 탄약을 보충하며, 듀얼 패드는 3D 로비 오른쪽에 있습니다.


### v22 controls and arenas
- Mobile: landscape layout, icon buttons, aim toggle and slide start/stop toggle. Rotate the phone if the browser cannot lock orientation.
- Sniper: single-round magazine, immediate trigger and reload after firing.
- The hidden robot entrance leads to the atrium; walk through the training gate for a 144 × 176 m two-story range with bots and floating one-hit targets. Trampolines reach the upper floor; stations respawn after three seconds.
- Ten structurally different maps include enclosed arenas, fatal perimeter boundaries, water and void gaps with accessible outer platforms.
- 36 uniquely named weapons, including six fantasy weapons and twenty active-ability melee weapons. Old purchases migrate with catalogue version 2.
- Melee: right-click / E activates the equipped ability. The HUD shows cooldown. Reflect, cover placement (8 seconds), directional dash, dash attack, backstab, slam and temporary triple jump are also checked by the online server.


### v23 fixes, shop and emotes
- The first-screen map list scrolls independently of combat input. Lobby robots are framed within phone and desktop viewports; double click / double tap still opens the hidden atrium.
- Mobile compatibility mouse events cannot cancel toggle aim; camera finger ownership survives multitouch releases. Slide changes to a stop icon while sliding. Near-ready sniper input is buffered through reload completion.
- Shop groups: primary, sidearm, melee. Selected owned weapons show the exact gameplay model and statistics; locked weapons show an alpha silhouette and description. Preview rendering does not change equipped weapons or ammunition.
- Five free emotes: T opens the picker, Y now refills practice ammunition. Moving, firing or being hit cancels a dance. Online emotes are validated by the server and synchronized to other players.
- HTML asset URLs include content hashes to prevent mixing an older cached bundle/style with new markup.
